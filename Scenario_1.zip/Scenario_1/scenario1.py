import pandas as pd 
import csv 
  

##############Creating a CSV file ####################

def createcsv():
	# assign header/columns 
	headerList = ['ID', 'SourceNumber', 'DestinationNumber', 'Message'] 
  
	# open CSV file and assign header 
	with open("sms.csv", 'w') as file: 
		dw = csv.DictWriter(file, delimiter=',',fieldnames=headerList) 
		dw.writeheader() 
  
	# display the csv file 
	fileContent = pd.read_csv("sms.csv")




##############Add data to a CSV file ####################

def appenddata(a,b,c,d):

	#adding data based on user input
	data_to_append=[[a,b,c,d]]
	# open CSV file and add the data_to_append
	file=open("sms.csv",'a',newline='')

	writer=csv.writer(file)

	writer.writerows(data_to_append)

	file.close()

createcsv()

appenddata(a=int(input("Enter the id")),b=input("Enter src name"),c=input("Enter dst name"),d=input("Enter message"))

