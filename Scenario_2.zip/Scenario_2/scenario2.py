import pandas as pd 
import csv 
  

##############Creating a CSV file ####################

def createcsv():
	# assign header/columns 
	citiesList = ['Mumbai', 'Bangalore', 'Chennai', 'Delhi'] 
  
	# open CSV file and assign header 
	with open("cities.csv", 'w') as file: 
		dw = csv.DictWriter(file, delimiter=',',fieldnames=headerList) 
		dw.writeheader() 
  
	# display the csv file 
	fileContent = pd.read_csv("cities.csv")
